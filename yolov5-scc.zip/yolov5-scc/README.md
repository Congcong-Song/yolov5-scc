# yolov5-scc
yolov5 code with MaskDataSet
